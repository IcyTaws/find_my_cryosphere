Service Desk Request #14212 put in by Steve Ansari

This directory will contain snow related products
